#!/bin/bash

prefix1='10.136.46.'
mgmt='106'
mgmt0='106'

SETUP='PDI'
