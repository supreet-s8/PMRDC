#!/bin/bash

prefix1='172.30.5.'
mgmt='57 58'
mgmt0='63'

SETUP='SMLAB'
