#!/bin/bash

prefix1='10.10.21.'
mgmt='68 69'
mgmt0='70'

SETUP='NORSE'
