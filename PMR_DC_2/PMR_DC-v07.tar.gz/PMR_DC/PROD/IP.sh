#!/bin/bash

prefix1='10.136.239.'
mgmt='63 65'
mgmt0='161'

SETUP='PROD'
